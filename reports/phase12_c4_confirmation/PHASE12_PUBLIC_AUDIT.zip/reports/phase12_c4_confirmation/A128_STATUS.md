# A128

All30 records persisted and independently recomputed; later locked models unchanged.
